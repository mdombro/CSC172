// Matthew Dombroski
// Lab 2 - Combinatrics part 1

In this lab basic combinatoric problems were solved by implementing Java methods to carry out the computation. A recursive factorial function was created in addition to permutation and combination computing functions.  
