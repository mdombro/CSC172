PROGRAMMER: Matthew Dombroski
PARTNER(S): Greg Hunkins
CONTACT: mdombros@u.rochester.edu

LAB4 DESCRIPTION: Lab 4 focused on writing a class to maintain a singly linked list. The functions for insert, delete, contains, lookup, printList and isEmpty were implemented per the lab write-up sepcifications. All methods were tested to work as expected with a sample output file attached. 


