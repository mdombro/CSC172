Author Matthew Dombroski
Partner: Greg Hunkins

Lab 10 Binary Search Tree

In this lab a basic binary tree class was implemented. The functions to insert, lookup, and print the list in several orders were implemented in the class. A function to delete elements was begun, however all the bugs were not ultimately worked out so it does not function.
Sample output can be found in OUTPUT.txt.
