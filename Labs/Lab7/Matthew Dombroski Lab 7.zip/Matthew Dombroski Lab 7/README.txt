PROGRAMMER: Matthew Dombroski
PARTNER(S): Gregory Hunkins
CONTACT: mdombros@u.rochester.edu

LAB7 DESCRIPTION: Lab7 focused on implementing a simple Queue using generic programming and double-linked lists. The stack is able to implement the peek, enqueue, dequeue, and isEmpty commands. The fundamental structure of the queue is based upon the Double LinkedList from Lab5. All testing of the methods in the main function was successful. The Lab folder itself contains a README.txt file with basic information, the Lab7.java program, and an OUTPUT.txt with basic output of the Lab7.java program.

