PROGRAMMER: Matthew Dombroski
PARTNER(S): Greg Hunkins
CONTACT: mdombros@u.rochester.edu

Lab 5 focused on writing a class to maintain a doubly linked list. The functions for insert, delete, contains, lookup, printList, printListRev and isEmpty were implemented per the lab write-up sepcifications. All methods were tested to work as expected with a sample output file attached. 
