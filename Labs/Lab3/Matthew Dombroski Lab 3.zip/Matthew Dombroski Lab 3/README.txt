Matthew Dombroski
Lab 3

Similar purpose as Lab 2 however in this lab more complex combinatorics functions were implemented. Specifically this lab dealt with ordering identical items, and sorting identical items into 'bins' and counting the number of arrangements possible in such scenarios.  
