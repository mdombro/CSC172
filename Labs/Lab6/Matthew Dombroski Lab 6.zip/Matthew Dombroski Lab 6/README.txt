PROGRAMMER: Matthew Dombroski
PARTNER(S): Gregory Hunkins
CONTACT: mdombros@u.rochester.edu

LAB4 DESCRIPTION: Lab 6 focused on implementing a simple Stack using generic programming. The stack is able to implment the push, pop, peek, and isEmpty commands. The fundamental structure of the stack is based upon the LinkedList from Lab4. All testing of the methods in the main function was successful. The Lab folder itself contains a README.txt file with basic information, the Lab4.java program, and an OUTPUT.txt with basic output of the Lab6.java program.

