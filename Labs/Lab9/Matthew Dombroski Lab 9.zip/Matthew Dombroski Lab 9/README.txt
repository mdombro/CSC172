PROGRAMMER: Matthew Dombroski
PARTNER(S): Gregory Hunkins
CONTACT: mdombros@u.rochester.edu

LAB7 DESCRIPTION: Lab 9 focused on implementing a linked list using the C langueage. Pointers, the arrow syntax, and malloc() were all used to implement a linked list that operates almost identically to the linked list created with Java in a previous lab. Attached in this folder is an output file and the sourcecode file.

