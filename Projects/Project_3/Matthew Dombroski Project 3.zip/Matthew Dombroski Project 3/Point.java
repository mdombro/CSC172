/*****************************/
/*    Matthew Dombroski      */
/*        Project 3          */
/*****************************/

public class Point {
    float x, y;
    Point (float x1, float y1) {
        x = x1;
        y = y1;
    }

    public float getx() {
        return x;
    }

    public float gety() {
        return y;
    }

    public void setPoint(float x1, float y1) {
        x = x1;
        y = y1;
    }
}
